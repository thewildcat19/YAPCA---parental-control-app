﻿namespace YAPCA
{
    partial class MainWindow
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }



        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWindow));
            trayIcon = new NotifyIcon(components);
            trayMenu = new ContextMenuStrip(components);
            button1 = new Button();
            listBox1 = new ListBox();
            button2 = new Button();
            label1 = new Label();
            label2 = new Label();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            listBox2 = new ListBox();
            label3 = new Label();
            numericUpDown1 = new NumericUpDown();
            numericUpDown2 = new NumericUpDown();
            button6 = new Button();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
            SuspendLayout();
            // 
            // trayIcon
            // 
            trayIcon.ContextMenuStrip = trayMenu;
            trayIcon.Icon = (Icon)resources.GetObject("trayIcon.Icon");
            trayIcon.Text = "Time Control";
            trayIcon.Visible = true;
            // 
            // trayMenu
            // 
            trayMenu.Name = "contextMenuStrip1";
            trayMenu.Size = new Size(61, 4);
            // 
            // button1
            // 
            button1.Location = new Point(47, 415);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(599, 12);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(189, 124);
            listBox1.TabIndex = 2;
            // 
            // button2
            // 
            button2.Location = new Point(713, 142);
            button2.Name = "button2";
            button2.Size = new Size(75, 40);
            button2.TabIndex = 3;
            button2.Text = "Add game app";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(47, 70);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 4;
            label1.Text = "label1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(219, 70);
            label2.Name = "label2";
            label2.Size = new Size(38, 15);
            label2.TabIndex = 5;
            label2.Text = "label2";
            // 
            // button3
            // 
            button3.Location = new Point(599, 142);
            button3.Name = "button3";
            button3.Size = new Size(75, 40);
            button3.TabIndex = 6;
            button3.Text = "Delete game app";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(381, 142);
            button4.Name = "button4";
            button4.Size = new Size(71, 40);
            button4.TabIndex = 9;
            button4.Text = "Delete edu app";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(495, 142);
            button5.Name = "button5";
            button5.Size = new Size(75, 40);
            button5.TabIndex = 8;
            button5.Text = "Add edu app";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(381, 12);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(189, 124);
            listBox2.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(47, 130);
            label3.Name = "label3";
            label3.Size = new Size(38, 15);
            label3.TabIndex = 10;
            label3.Text = "label3";
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(599, 250);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(189, 23);
            numericUpDown1.TabIndex = 11;
            // 
            // numericUpDown2
            // 
            numericUpDown2.Location = new Point(381, 250);
            numericUpDown2.Name = "numericUpDown2";
            numericUpDown2.Size = new Size(189, 23);
            numericUpDown2.TabIndex = 12;
            // 
            // button6
            // 
            button6.Location = new Point(552, 326);
            button6.Name = "button6";
            button6.Size = new Size(71, 40);
            button6.TabIndex = 13;
            button6.Text = "Set limits";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // MainWindow
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button6);
            Controls.Add(numericUpDown2);
            Controls.Add(numericUpDown1);
            Controls.Add(label3);
            Controls.Add(button4);
            Controls.Add(button5);
            Controls.Add(listBox2);
            Controls.Add(button3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(listBox1);
            Controls.Add(button1);
            Name = "MainWindow";
            Text = "Form1";
            FormClosing += MainWindow_FormClosing;
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private NotifyIcon trayIcon;
        private ContextMenuStrip trayMenu;
        private Button button1;
        private ListBox listBox1;
        private Button button2;
        private Label label1;
        private Label label2;
        private Button button3;
        private Button button4;
        private Button button5;
        private ListBox listBox2;
        private Label label3;
        private NumericUpDown numericUpDown1;
        private NumericUpDown numericUpDown2;
        private Button button6;
    }
}
