﻿using System.Diagnostics;

namespace YAPCA;

public class AppKiller
{
    public static void CloseApp(string appName)
    {
        // Получаем список процессов с именем, совпадающим с appName
        var processes = Process.GetProcessesByName(appName);

        // Закрываем все найденные процессы
        foreach (var process in processes)
        {
            try
            {
                process.Kill(); // Убиваем процесс
            }
            catch (Exception ex)
            {
                // Обработка ошибок, например, если процесс не может быть завершен
                Console.WriteLine($"Error killing process {appName}: {ex.Message}");
            }
        }
    }


    //public static void CloseApps(IEnumerable<string> appName)
    //{
    //    var processes = appName.SelectMany(name => Process.GetProcessesByName(name)).ToList();

    //    processes.ForEach(processes => processes.Kill());
    //}
}