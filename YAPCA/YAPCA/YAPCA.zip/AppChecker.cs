﻿using System.Diagnostics;
using System.Security;
using System.Windows.Forms;

namespace YAPCA;

public class AppChecker
{
    private static bool gameAppsBlockedNotified = false;
    private static bool gamesUnlockedNotified = false;

    public static void Check(string appName, TrayNotificationService notificationService)
    {
        

    
        if (ConfigManager.Config.EducationalTime >= ConfigManager.Config.EducationalLimit && !gamesUnlockedNotified)
        {
            notificationService.ShowNotification(
                "Game Apps Unlocked",
                "You have completed your educational time limit. Game apps are now unlocked.",
                ToolTipIcon.Info
            );
            gamesUnlockedNotified = true; // Уведомление больше не показывать
            ConfigManager.Config.AreGamesUnlocked = true;
        }


        if (ConfigManager.Config.GameApps.Any(app => appName.Contains(app)))
        {
            if ((ConfigManager.Config.GameTime < ConfigManager.Config.GameLimit ))
            {
                if (ConfigManager.Config.AreGamesUnlocked)
                {
                    Logger.LogGame(appName);
                }
                else
                {
                    notificationService.ShowNotification(
                        "Game Apps Blocked",
                        "Game apps are blocked until you finish your educational time.",
                        ToolTipIcon.Warning
                    );
                    gameAppsBlockedNotified = true;
                    AppKiller.CloseApp(appName);
                }
            }
            else
            {
                notificationService.ShowNotification("Game time limit exceeded",
                    $"You`ve exceeded your time limit for games ({ConfigManager.Config.GameLimit / 60} minutes)",
                    ToolTipIcon.Warning);
                gameAppsBlockedNotified = false;
                AppKiller.CloseApp(appName);
                
            }
            
        }
        else if (ConfigManager.Config.EducationalApps.Any(app => appName.Contains(app)))
        {
            if (ConfigManager.Config.EducationalTime < ConfigManager.Config.EducationalLimit)
            {
                Logger.LogEducation(appName);
            }
            else
            {
                AppKiller.CloseApp(appName);
            }
        }
    }
}